  // Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fabric-assets-license

// tslint:disable:max-line-length

import {
  IIconOptions,
  IIconSubset,
  registerIcons
} from '@uifabric/styling';

export function initializeIcons(
  baseUrl: string = '',
  options?: IIconOptions
): void {
  const subset: IIconSubset = {
    style: {
      MozOsxFontSmoothing: 'grayscale',
      WebkitFontSmoothing: 'antialiased',
      fontStyle: 'normal',
      fontWeight: 'normal',
      speak: 'none'
    },
    fontFace: {
      fontFamily: `"FabricMDL2Icons"`,
      src: `url('${baseUrl}fabric-icons.woff') format('woff')`
    },
    icons: {
      'ChevronDown': '\uE70D',
      'ChevronUp': '\uE70E',
      'Add': '\uE710',
      'Cancel': '\uE711',
      'Settings': '\uE713',
      'Mail': '\uE715',
      'Stop': '\uE71A',
      'Filter': '\uE71C',
      'Zoom': '\uE71E',
      'Search': '\uE721',
      'Checkbox': '\uE739',
      'CheckMark': '\uE73E',
      'Print': '\uE749',
      'Up': '\uE74A',
      'Down': '\uE74B',
      'Delete': '\uE74D',
      'Play': '\uE768',
      'Pause': '\uE769',
      'Warning': '\uE7BA',
      'Clear': '\uE894',
      'ChromeClose': '\uE8BB',
      'Copy': '\uE8C8',
      'RadioBullet': '\uE915',
      'ChevronUpSmall': '\uE96D',
      'ChevronDownSmall': '\uE96E',
      'ChevronUpMed': '\uE971',
      'ChevronDownMed': '\uE972',
      'SortLines': '\uE9D0',
      'OpenFolderHorizontal': '\uED25',
      'FolderHorizontal': '\uF12B',
      'SignOut': '\uF3B1'
    }
  };

  registerIcons(subset, options);
}
